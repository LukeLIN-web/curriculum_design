﻿int lqueue_is_empty(ListEntry *lqueue) {
    return list_is_empty(lqueue);
}