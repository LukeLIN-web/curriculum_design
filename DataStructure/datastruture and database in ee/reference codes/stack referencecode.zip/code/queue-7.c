﻿unsigned int lqueue_length(ListEntry *lqueue) {
	return list_length(lqueue);
}