﻿queue_new：建立一个空队列。

queue_free：清除一个队列，并释放内存。

queue_is_empty：若队列空，则返回1；否则返回0。

queue_is_full：若队列满，则返回1；否则返回0。

queue_peek_head：返回队头元素。

queue_push_tail：在队尾插入元素x。

queue_pop_head：从队列中删除队头元素，并返回队头元素。

queue_clear：清除队列中全部元素。

queue_length：返回队列的长度。