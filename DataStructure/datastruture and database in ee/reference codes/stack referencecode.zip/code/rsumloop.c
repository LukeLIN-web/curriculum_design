int rsum(int list[], int n) {
	int i;
	for(i = n - 1; i >= 0; i--)
		printf("%d\n", list[i]);
}