﻿creat_stack：建立一个空栈。

dispose_stack：撤销一个栈。

is_empty：若栈空，则返回true；否则返回false。

is_full：若栈满，则返回true；否则返回false。

top：在x中返回栈顶元。若操作成功，则返回true；否则返回false。

push：在栈顶插入元素x(入栈)。

pop：从栈中删除栈顶元素(出栈)。

make_empty：清除栈中全部元素。