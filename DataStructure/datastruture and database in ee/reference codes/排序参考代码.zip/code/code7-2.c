﻿typedef struct {
	KeyType key;	/* 关键字字段，可以时整型、字符串型、构造类型等 */
	...... 	/* 其他字段 */ 
}ElementType;