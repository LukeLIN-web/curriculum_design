﻿typedef struct{
	BiTreeNode *link;
	int flag;
}stacktype;