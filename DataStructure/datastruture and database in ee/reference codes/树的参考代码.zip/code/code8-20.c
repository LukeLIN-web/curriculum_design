﻿if(a < 60)
	b = "bad";
else if(a < 70)
	b = "pass";
else if(a < 80)
	b = "general";
else if(a < 90)
	b = "good";
else
	b = "excellent";