open the .c file 
you can use:
gcc mycodes.c -o mycodes
generate .exe file.