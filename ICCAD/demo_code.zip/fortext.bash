for ((i=0; i<100; i++)); do /usr/games/fortune; done > tmptxt
