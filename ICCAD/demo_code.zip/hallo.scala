//object Hello {
//  def main(args: Array[String]) = println("hello world!")
//}

object Hallo {
  def main(args: Array[String]) = println("hallo world!")
}
